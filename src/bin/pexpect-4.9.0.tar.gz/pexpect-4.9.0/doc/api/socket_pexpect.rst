socket_pexpect - use pexpect with a socket
==========================================

.. automodule:: pexpect.socket_pexpect

SocketSpawn class
-----------------

.. autoclass:: SocketSpawn
   :show-inheritance:

   .. automethod:: __init__
   .. automethod:: isalive
   .. automethod:: close

   .. method:: expect
               expect_exact
               expect_list

      As :class:`pexpect.spawn`.
